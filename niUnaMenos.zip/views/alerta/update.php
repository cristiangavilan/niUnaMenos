<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Alerta */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Alerta',
]) . $model->id_alerta;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Alertas'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_alerta, 'url' => ['view', 'id' => $model->id_alerta]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="alerta-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
